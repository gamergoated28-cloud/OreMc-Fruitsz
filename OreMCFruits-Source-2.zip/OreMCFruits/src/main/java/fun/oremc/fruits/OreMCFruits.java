package fun.oremc.fruits;

import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.block.Action;
import org.bukkit.event.inventory.*;
import org.bukkit.event.player.*;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.*;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

public final class OreMCFruits extends JavaPlugin implements Listener, CommandExecutor {
    private final Map<UUID, String> equipped = new HashMap<>();
    private final Map<UUID, Integer> selected = new HashMap<>();
    private final Map<UUID, Long> cooldowns = new HashMap<>();
    private final Map<UUID, Long> spinLocks = new HashMap<>();
    private File dataFile;
    private YamlConfiguration data;
    private final List<Fruit> fruits = List.of(
        new Fruit("flame", "Flame", "§c", Material.BLAZE_POWDER, 1001, "RARE", new String[]{"Ember Bolt","Fire Dash","Heat Shield","Inferno Wave","Solar Burst"}),
        new Fruit("frost", "Frost", "§b", Material.PACKED_ICE, 1002, "RARE", new String[]{"Ice Shard","Glacier Step","Frost Guard","Blizzard Ring","Absolute Zero"}),
        new Fruit("thunder", "Thunder", "§e", Material.LIGHTNING_ROD, 1003, "EPIC", new String[]{"Spark Shot","Volt Rush","Static Guard","Thunder Call","Storm Crown"}),
        new Fruit("shadow", "Shadow", "§8", Material.INK_SAC, 1004, "EPIC", new String[]{"Dark Pulse","Shade Step","Umbral Guard","Nightfall","Eclipse"}),
        new Fruit("light", "Light", "§f", Material.GLOWSTONE_DUST, 1005, "LEGENDARY", new String[]{"光 Ray","Flash Step","Radiant Guard","Prism Burst","Heaven's Gate"}),
        new Fruit("gravity", "Gravity", "§5", Material.AMETHYST_SHARD, 1006, "LEGENDARY", new String[]{"Gravity Orb","Lift Step","Mass Shield","Meteor Pull","Singularity"}),
        new Fruit("dragon", "Dragon", "§6", Material.DRAGON_BREATH, 1007, "MYTHICAL", new String[]{"Dragon Claw","Dragon Dash","Scale Guard","Drake Breath","Dragon Awakening"}),
        new Fruit("phoenix", "Phoenix", "§d", Material.PHANTOM_MEMBRANE, 1008, "MYTHICAL", new String[]{"Flare Shot","Wing Burst","Rebirth Guard","Ashen Rain","Phoenix Rise"}),
        new Fruit("void", "Void", "§0", Material.ENDER_PEARL, 1009, "SECRET", new String[]{"Void Bolt","Rift Step","Null Guard","Dark Matter","Event Horizon"}),
        new Fruit("celestial", "Celestial", "§b§l", Material.NETHER_STAR, 1010, "SECRET", new String[]{"Star Lance","Astral Step","Cosmic Ward","Nova Field","Celestial Ascension"})
    );

    @Override public void onEnable() {
        saveDefaultConfig();
        dataFile = new File(getDataFolder(), "players.yml");
        if (!dataFile.exists()) try { getDataFolder().mkdirs(); dataFile.createNewFile(); } catch (IOException e) { getLogger().severe("Could not create players.yml: " + e.getMessage()); }
        data = YamlConfiguration.loadConfiguration(dataFile);
        loadPlayers();
        Bukkit.getPluginManager().registerEvents(this, this);
        Objects.requireNonNull(getCommand("fruit")).setExecutor(this);
        getLogger().info("OreMCFruits enabled. Fruit abilities never edit blocks or create explosions.");
    }
    @Override public void onDisable() { savePlayers(); }

    private void loadPlayers() {
        for (String key : data.getKeys(false)) {
            try { UUID id = UUID.fromString(key); String f = data.getString(key + ".equipped"); if (f != null) equipped.put(id, f); }
            catch (IllegalArgumentException ignored) {}
        }
    }
    private void savePlayers() {
        for (UUID id : new HashSet<>(equipped.keySet())) data.set(id + ".equipped", equipped.get(id));
        try { data.save(dataFile); } catch (IOException e) { getLogger().severe("Could not save players.yml: " + e.getMessage()); }
    }

    @EventHandler public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        if (!data.getBoolean(p.getUniqueId() + ".first-join-claimed", false)) {
            data.set(p.getUniqueId() + ".first-join-claimed", true);
            data.set(p.getUniqueId() + ".spins", 1);
            Bukkit.getScheduler().runTaskLater(this, () -> spin(p, true), 40L);
            savePlayers();
        }
    }
    @EventHandler public void onQuit(PlayerQuitEvent e) { selected.remove(e.getPlayer().getUniqueId()); }

    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) { sender.sendMessage("Players only."); return true; }
        if (args.length == 0) { openMenu(p); return true; }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "spin" -> spin(p, false);
            case "storage" -> openStorage(p);
            case "equip" -> { if (args.length < 2) p.sendMessage("§bUsage: /fruit equip <name>"); else equip(p, args[1]); }
            case "admin" -> { if (!p.hasPermission("oremcfruits.admin")) { p.sendMessage("§cNo permission."); return true; } if (args.length >= 3 && args[1].equalsIgnoreCase("give")) giveFruit(Bukkit.getPlayerExact(args[2]), args.length >= 4 ? args[3] : "flame"); else if (args.length >= 4 && args[1].equalsIgnoreCase("spins")) { Player target = Bukkit.getPlayerExact(args[2]); if (target != null) { int amount; try { amount = Integer.parseInt(args[3]); } catch (NumberFormatException ex) { p.sendMessage("§cAmount must be a number."); return true; } data.set(target.getUniqueId() + ".spins", Math.max(0, data.getInt(target.getUniqueId() + ".spins") + amount)); savePlayers(); target.sendMessage("§bYour spin balance: §f" + data.getInt(target.getUniqueId() + ".spins")); } } else p.sendMessage("§b/fruit admin give <player> <fruit> | /fruit admin spins <player> <amount>"); }
            default -> openMenu(p);
        }
        return true;
    }

    private void openMenu(Player p) {
        Inventory inv = Bukkit.createInventory(null, 27, "§8OreMC §bFruits");
        inv.setItem(11, button(Material.NETHER_STAR, "§b§lSpin Fruit", "§7Use your free or earned spin."));
        inv.setItem(13, button(Material.CHEST, "§e§lFruit Storage", "§7View fruits you own."));
        inv.setItem(15, button(Material.ENCHANTED_BOOK, "§d§lAbilities", "§7Sneak + right-click to cycle."));
        p.openInventory(inv);
    }
    private void openStorage(Player p) {
        Inventory inv = Bukkit.createInventory(null, 27, "§8Your Fruit");
        String f = equipped.get(p.getUniqueId());
        if (f != null) { Fruit fruit = find(f); if (fruit != null) inv.setItem(13, fruitItem(fruit)); }
        else inv.setItem(13, button(Material.BARRIER, "§cNo fruit equipped", "§7Use /fruit spin to get one."));
        p.openInventory(inv);
    }
    @EventHandler public void onMenu(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        String title = e.getView().getTitle();
        if (!title.startsWith("§8OreMC") && !title.startsWith("§8Your Fruit") && !title.equals("§8§lOREMC • FRUIT SPIN")) return;
        e.setCancelled(true);
        if (e.getCurrentItem() == null) return;
        if (title.equals("§8OreMC §bFruits")) {
            if (e.getSlot() == 11) spin(p, false);
            if (e.getSlot() == 13) openStorage(p);
            if (e.getSlot() == 15) { p.closeInventory(); p.sendMessage("§bHold your fruit: sneak + right-click to cycle, right-click to use."); }
        }
    }

    private void spin(Player p, boolean firstJoin) {
        UUID id = p.getUniqueId(); long now = System.currentTimeMillis();
        if (spinLocks.getOrDefault(id, 0L) > now) { p.sendMessage("§cYour spin is already running."); return; }
        if (!firstJoin) { int balance = data.getInt(id + ".spins", 0); if (balance < 1) { p.sendMessage("§cYou have no spins. Earn one or ask an admin."); return; } data.set(id + ".spins", balance - 1); savePlayers(); }
        spinLocks.put(id, now + 5000);
        Inventory inv = Bukkit.createInventory(null, 27, "§8§lOREMC • FRUIT SPIN");
        for (int i = 0; i < 27; i++) inv.setItem(i, button(Material.BLACK_STAINED_GLASS_PANE, " ", ""));
        inv.setItem(13, button(Material.NETHER_STAR, "§b§lSPINNING...", "§7A mystery fruit is coming!"));
        p.openInventory(inv);
        final int[] ticks = {0};
        Bukkit.getScheduler().runTaskTimer(this, task -> {
            if (!p.isOnline() || !p.getOpenInventory().getTitle().equals("§8§lOREMC • FRUIT SPIN")) { task.cancel(); spinLocks.remove(id); return; }
            Fruit preview = fruits.get(ThreadLocalRandom.current().nextInt(fruits.size()));
            inv.setItem(13, fruitItem(preview));
            p.playSound(p.getLocation(), Sound.UI_BUTTON_CLICK, 0.6f, 1.2f + (ticks[0] % 5) * 0.12f);
            ticks[0]++;
            if (ticks[0] >= 24) {
                task.cancel(); Fruit won = fruits.get(ThreadLocalRandom.current().nextInt(fruits.size()));
                equipped.put(id, won.id); data.set(id + ".equipped", won.id); savePlayers();
                inv.setItem(13, fruitItem(won)); p.playSound(p.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 1f);
                p.sendTitle("§b§l" + won.name.toUpperCase(Locale.ROOT) + " FRUIT", "§7" + won.rarity + " • Your new power awaits", 5, 55, 10);
                p.sendMessage("§aYou received " + won.color + won.name + " Fruit§a!"); spinLocks.remove(id);
            }
        }, 0L, 3L);
    }

    private void equip(Player p, String id) {
        Fruit f = find(id); if (f == null) { p.sendMessage("§cUnknown fruit. Available: flame, frost, thunder, shadow, light, gravity, dragon, phoenix, void, celestial"); return; }
        equipped.put(p.getUniqueId(), f.id); data.set(p.getUniqueId() + ".equipped", f.id); savePlayers(); p.getInventory().addItem(fruitItem(f)); p.sendMessage("§aEquipped " + f.color + f.name + " Fruit§a.");
    }
    private void giveFruit(Player p, String id) { if (p == null) return; Fruit f = find(id); if (f == null) { p.sendMessage("§cUnknown fruit."); return; } p.getInventory().addItem(fruitItem(f)); p.sendMessage("§aYou received " + f.name + " Fruit."); }

    @EventHandler public void onInteract(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        Action a = e.getAction(); if (a != Action.RIGHT_CLICK_AIR && a != Action.RIGHT_CLICK_BLOCK) return;
        Player p = e.getPlayer(); ItemStack item = e.getItem(); if (item == null || !item.hasItemMeta()) return;
        ItemMeta meta = item.getItemMeta(); if (!meta.hasCustomModelData()) return;
        int model = meta.getCustomModelData(); if (model < 1001 || model > 1010) return;
        e.setCancelled(true);
        if (p.isSneaking()) { int next = (selected.getOrDefault(p.getUniqueId(), 0) + 1) % 5; selected.put(p.getUniqueId(), next); Fruit f = fruits.get(model - 1001); p.sendActionBar("§b" + f.abilities[next] + " §7(" + (next + 1) + "/5)"); p.playSound(p.getLocation(), Sound.UI_BUTTON_CLICK, 0.7f, 1.4f); }
        else cast(p, fruits.get(model - 1001), selected.getOrDefault(p.getUniqueId(), 0));
    }

    private void cast(Player p, Fruit f, int ability) {
        if (isProtected(p.getLocation())) { p.sendActionBar("§cAbilities are disabled in this protected area."); return; }
        String key = p.getUniqueId() + ":" + f.id + ":" + ability; long now = System.currentTimeMillis();
        if (cooldowns.getOrDefault(UUID.nameUUIDFromBytes(key.getBytes()), 0L) > now) { p.sendActionBar("§cAbility cooling down."); return; }
        cooldowns.put(UUID.nameUUIDFromBytes(key.getBytes()), now + (ability == 4 ? 45000 : 8000));
        Location loc = p.getLocation(); Vector dir = loc.getDirection().normalize();
        p.getWorld().spawnParticle(particle(f), loc.clone().add(0, 1, 0), ability == 4 ? 70 : 20, 0.6, 0.6, 0.6, 0.03);
        p.getWorld().playSound(loc, Sound.ENTITY_ILLUSIONER_CAST_SPELL, 0.8f, 0.8f + ability * 0.12f);
        switch (ability) {
            case 0 -> { for (Entity entity : p.getNearbyEntities(7, 4, 7)) if (entity instanceof LivingEntity target && target != p && target instanceof Player && !isProtected(target.getLocation())) { target.damage(4.0, p); target.setVelocity(dir.multiply(0.45).setY(0.18)); } }
            case 1 -> { p.setVelocity(dir.clone().multiply(1.15).setY(Math.max(0.25, dir.getY() * 0.5 + 0.25))); }
            case 2 -> { p.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, 100, 1)); p.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 100, 0)); }
            case 3 -> { for (Entity entity : p.getNearbyEntities(5, 3, 5)) if (entity instanceof LivingEntity target && target instanceof Player && target != p && !isProtected(target.getLocation())) { target.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 60, 1)); target.damage(2.0, p); } }
            case 4 -> { p.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 160, 1)); p.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, 160, 1)); p.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 160, 1)); }
        }
        p.sendActionBar("§b" + f.abilities[ability] + " §8• §7Cooldown started");
    }
    private boolean isProtected(Location l) {
        if (getConfig().getStringList("protection.disabled-worlds").contains(l.getWorld().getName())) return true;
        if (getConfig().getBoolean("protection.spawn-radius.enabled", true)) {
            String world = getConfig().getString("protection.spawn-radius.world", "world");
            if (l.getWorld().getName().equals(world)) {
                Location center = new Location(l.getWorld(), getConfig().getDouble("protection.spawn-radius.x", 0), getConfig().getDouble("protection.spawn-radius.y", 64), getConfig().getDouble("protection.spawn-radius.z", 0));
                if (l.distanceSquared(center) <= Math.pow(getConfig().getDouble("protection.spawn-radius.radius", 100), 2)) return true;
            }
        }
        return false;
    }
    private Particle particle(Fruit f) { return switch (f.id) { case "flame","phoenix" -> Particle.FLAME; case "frost" -> Particle.SNOWFLAKE; case "thunder" -> Particle.ELECTRIC_SPARK; case "shadow","void" -> Particle.PORTAL; case "light","celestial" -> Particle.END_ROD; case "gravity" -> Particle.REVERSE_PORTAL; default -> Particle.DRAGON_BREATH; }; }
    private ItemStack fruitItem(Fruit f) { ItemStack item = new ItemStack(f.material); ItemMeta m = item.getItemMeta(); m.setDisplayName(f.color + "§l" + f.name + " Fruit"); m.setCustomModelData(f.model); m.setLore(List.of("§7Rarity: " + f.color + f.rarity, "§7Sneak + Right-click: §fSwitch ability", "§7Right-click: §fUse ability", "", "§8OreMC Original Fruit")); item.setItemMeta(m); return item; }
    private ItemStack button(Material mat, String name, String lore) { ItemStack i = new ItemStack(mat); ItemMeta m = i.getItemMeta(); m.setDisplayName(name); m.setLore(List.of(lore)); i.setItemMeta(m); return i; }
    private Fruit find(String id) { for (Fruit f : fruits) if (f.id.equalsIgnoreCase(id) || f.name.equalsIgnoreCase(id)) return f; return null; }
    private record Fruit(String id, String name, String color, Material material, int model, String rarity, String[] abilities) {}
}
