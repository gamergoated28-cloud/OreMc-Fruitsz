# OreMCFruits (development starter)

Paper 1.21.11 / Java 21 project. This is an initial playable foundation, not a finished production release.

## Build
Install JDK 21 and Maven, then run in this folder:

```bash
mvn clean package
```

The plugin jar will be at `target/oremc-fruits-1.0.0.jar`.

## Install
1. Back up the server.
2. Put the jar in `plugins/` and start the server once.
3. Edit `plugins/OreMCFruits/config.yml` to set the lobby/spawn world names and spawn-radius center.
4. Restart the server.

## Commands
- `/fruit` — main menu
- `/fruit spin` — spin (permission `oremcfruits.spin`; first join gets one automatically)
- `/fruit storage` — view equipped fruit
- `/fruit equip <fruit>` — admin/testing equip command (currently available to all players; restrict before public launch)
- `/fruit admin give <player> <fruit>` — admin give
- `/fruit admin spins <player> <amount>` — add or remove spins (negative amount removes)

## Controls
Hold a fruit item. Sneak + right-click cycles the five ability slots; right-click casts the selected slot.

## Important limitations in this starter
- The 10 fruits, names, rarity tiers, GUI, first-join spin, and input handling are present.
- This first build is a framework/prototype: the five ability slots currently use shared safe effect patterns rather than 50 fully bespoke mechanics. The fruit-specific visual effects are basic Bukkit particles; the included resource pack is a texture starter, not a complete custom 3D model pack.
- Spin balance is stored per player; first join receives one spin. Admins can add/remove spins with `/fruit admin spins <player> <amount>`.
- Protection is based on disabled world names and a configurable spawn radius. It does not query WorldGuard regions. Add every lobby/spawn world to `disabled-worlds` for strongest protection.
- This code does not create explosions, set blocks, place fire, or alter terrain. Damage effects are player-only in this starter.
- Test on a staging server before production. This is not yet a zero-lag or production-certified release.
